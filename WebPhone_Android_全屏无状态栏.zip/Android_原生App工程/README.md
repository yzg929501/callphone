# WebPhone 原生 App 工程（Android / Kotlin）

把已经做好的拨号界面装进一个**全屏原生壳**里。装到手机后从桌面图标启动，
没有浏览器地址栏、没有底部工具栏，连系统状态栏和导航栏都隐藏，页面自绘的状态栏顶在最上面。

## 构建

1. 用 **Android Studio**（Ladybug 或更新版本）打开本目录（`Android_原生App工程`）。
2. 等 Gradle Sync 完成。
3. 手机开启「USB 调试」并连接电脑 → 点 **Run ▶**，直接装到手机。
   或者菜单 **Build → Build App Bundle(s) / APK(s) → Build APK(s)**，把生成的 APK 传到手机安装。

> 本环境没有 Android SDK，因此没有预编译好的 APK；工程文件是完整可构建的。

### 没有电脑 / 不想装 Android Studio

本目录自带 `.github/workflows/build-apk.yml`。把**本目录内容**单独推成一个 GitHub 仓库，打开仓库 **Actions** 页 → 点 **Run workflow**，几分钟后在 **Artifacts** 里下载 `WebPhone-debug.apk`，传到手机装即可。JDK 17、Android SDK 35、Gradle 8.7 都由云端自动准备。

（若推的是包含本目录的上层整包，请用整包根目录 `.github/workflows/build-apk.yml`，它会自动进入这个子目录编译。）

工程里没有 `gradlew` 与 wrapper jar，Android Studio 打开时会自动生成；云端 workflow 直接用 `gradle` 命令，不依赖 wrapper。

## 已经处理好的细节

- **沉浸式全屏**：`WindowInsetsControllerCompat` 隐藏 systemBars，上滑才临时显示；`shortEdges` 让内容延伸到刘海区。
- **不白闪**：`windowBackground` 与 WebView 底色都是 `#0B0C10`，冷启动也是深色。
- **稳定源站**：用 `WebViewAssetLoader` 把 `assets/` 映射成 `https://appassets.androidplatform.net/assets/`，
  所以 `localStorage` 有固定 origin，联系人和通话记录能持久保存（直接 `file://` 会踩坑）。
- **真实拨号**：拦截 `tel:` 链接，转成 `Intent.ACTION_DIAL` 调起系统拨号器，不需要 `CALL_PHONE` 权限。
- **DTMF 音可用**：`mediaPlaybackRequiresUserGesture = false`，按键音不会被拦。
- **不露白边**：WebView `overScrollMode=never`，过度滚动不会拉出白底。
- **自适应图标**：`mipmap-anydpi-v26` + 前景图，各家桌面不会给图标套白底。

## 目录速览

```
app/src/main/
├── AndroidManifest.xml
├── java/com/webphone/dialer/MainActivity.kt   ← 全屏、WebView、tel: 拦截
├── res/layout/activity_main.xml
├── res/values/{styles,colors,strings}.xml
├── res/mipmap-*/ic_launcher.png / ic_launcher_foreground.png
├── res/mipmap-anydpi-v26/ic_launcher.xml
└── assets/index.html                          ← 拨号界面（与网页版同一份）
```

## 改界面

直接替换 `app/src/main/assets/index.html` 即可，其余不用动。

## 注意

应用内的呼叫/接听/计时仍是高仿真模拟（网页无法接入运营商语音网络）。
只有点「系统拨号器拨打」这一条是真的拨号。
