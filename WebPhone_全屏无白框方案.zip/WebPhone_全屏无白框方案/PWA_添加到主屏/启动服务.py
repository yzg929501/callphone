# -*- coding: utf-8 -*-
"""在本机起一个静态服务，方便手机连同一 WiFi 预览 / 添加到主屏幕。"""
import os, socket, sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

PORT = 8000
os.chdir(os.path.dirname(os.path.abspath(__file__)))

def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('223.5.5.5', 80))
        return s.getsockname()[0]
    except Exception:
        return '127.0.0.1'
    finally:
        s.close()

class Handler(SimpleHTTPRequestHandler):
    def end_headers(self):
        # 让页面改动即时生效
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()

ip = lan_ip()
print('=' * 52)
print('  WebPhone 全屏版 · 本地服务已启动')
print('=' * 52)
print('  本机预览：   http://localhost:%d' % PORT)
print('  手机访问：   http://%s:%d   （需同一 WiFi）' % (ip, PORT))
print()
print('  iPhone：用 Safari 打开上面的手机地址 → 分享 → 添加到主屏幕')
print('  Android：PWA 安装需要 HTTPS，请把本目录部署到静态托管；')
print('           或直接使用 Android_原生App工程 构建 APK。')
print()
print('  按 Ctrl+C 停止')
print('=' * 52)

try:
    ThreadingHTTPServer(('0.0.0.0', PORT), Handler).serve_forever()
except KeyboardInterrupt:
    print('\n已停止')
except OSError as e:
    print('端口被占用，换个端口或关掉占用程序：', e)
    sys.exit(1)
