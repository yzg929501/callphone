/* WebPhone：独立窗口引导 + 离线注册 */
(function () {
  var isStandalone = window.matchMedia('(display-mode: standalone)').matches ||
                     window.matchMedia('(display-mode: minimal-ui)').matches ||
                     window.navigator.standalone === true;
  var isPhoneLike = window.matchMedia('(max-width: 860px)').matches;
  var isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) ||
              (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  var isSecure = location.protocol === 'https:' ||
                 location.hostname === 'localhost' || location.hostname === '127.0.0.1';

  if (isStandalone || window.navigator.standalone === true) {
    document.body.classList.add('pwa-standalone');
    if (isIOS) document.body.classList.add('pwa-ios');
  }

  /* Service Worker 只在安全上下文可用 */
  if ('serviceWorker' in navigator && isSecure) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js').catch(function () {});
    });
  }

  if (isStandalone || !isPhoneLike) return;
  if (sessionStorage.getItem('webphone-tip-closed') === '1') return;

  var deferred = null;
  var bar = document.createElement('div');
  bar.id = 'pwaInstallBar';
  bar.innerHTML =
    '<button class="pwa-close" aria-label="关闭">×</button>' +
    '<div class="pwa-title">想要全屏、没有白框？</div>' +
    '<div>把 WebPhone 添加到主屏幕，就从桌面图标启动，地址栏和工具栏都会消失。</div>' +
    '<div class="pwa-actions">' +
      '<button class="primary" data-pwa="install">立即安装</button>' +
      '<button data-pwa="how">怎么添加</button>' +
    '</div>' +
    '<div class="pwa-steps" style="display:none">' +
      (isIOS
        ? '<b>iPhone：</b>点 Safari 底部「分享」→「添加到主屏幕」→ 回桌面点图标打开。'
        : '<b>Android：</b>Chrome 菜单「⋮」→「安装应用 / 添加到主屏幕」。若没有该选项，说明当前不是 HTTPS 地址，请换 HTTPS 托管或直接安装 APK 版。') +
    '</div>';
  document.getElementById('device').appendChild(bar);
  setTimeout(function () { bar.classList.add('show'); }, 700);

  bar.querySelector('.pwa-close').addEventListener('click', function () {
    bar.classList.remove('show');
    sessionStorage.setItem('webphone-tip-closed', '1');
  });
  bar.querySelector('[data-pwa="how"]').addEventListener('click', function () {
    var s = bar.querySelector('.pwa-steps');
    s.style.display = s.style.display === 'none' ? 'block' : 'none';
  });
  bar.querySelector('[data-pwa="install"]').addEventListener('click', function () {
    if (deferred) { deferred.prompt(); deferred = null; return; }
    var s = bar.querySelector('.pwa-steps');
    s.style.display = 'block';
  });

  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    deferred = e;
    bar.querySelector('[data-pwa="install"]').textContent = '立即安装';
  });
  window.addEventListener('appinstalled', function () {
    bar.classList.remove('show');
  });
})();
