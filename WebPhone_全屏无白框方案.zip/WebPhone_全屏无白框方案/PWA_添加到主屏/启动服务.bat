@echo off
chcp 65001 >nul
python "%~dp0启动服务.py"
pause
