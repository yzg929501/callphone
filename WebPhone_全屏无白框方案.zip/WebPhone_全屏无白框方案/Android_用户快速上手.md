# Android 专用 · 三步去掉白框

你是 Android，推荐直接装 APK。选一条能走的：

---

## A. 没有电脑 / 不想装 Android Studio（推荐，手机就能操作）

用 GitHub 的免费云端编译，不用本地装任何开发环境。

1. 新建 GitHub 仓库（手机浏览器登录 GitHub → 「+」→ New repository），名字随意，例如 `webphone`，选 **Public**。
2. 解压 `WebPhone_Android工程.zip`，把里面**全部内容**（`.github/`、`Android_原生App工程/`、`Android_用户快速上手.md`）原样上传到仓库根目录。
   - 别只传工程子目录：根目录的 `.github/workflows/build-apk.yml` 是自动编译的开关，缺了它 Actions 不会跑。
   - 手机不方便传文件夹的话，用电脑解压后拖到 GitHub 网页的上传区即可。
3. 打开仓库的 **Actions** 页 → 左侧「构建 WebPhone APK」→ 点 **Run workflow** → 等 5～15 分钟（首次要下载 Android SDK、Gradle 和依赖）。
4. 构建完成后点进这次运行，最下面 **Artifacts** 下载 `WebPhone-debug-apk`，解压得到 `WebPhone-debug.apk`。
5. 把 APK 传到手机，点安装（需允许「安装未知来源应用」）→ 桌面出现 WebPhone 图标 → 打开即全屏。

> 两种推法都支持：推整个 `WebPhone_全屏无白框方案/` 解压目录，或只把 `Android_原生App工程` 文件夹内容推成仓库（用它自带的 `.github/workflows/`）。包里两份配置会自动适配，但**推荐用上面的整包推法**，最不容易漏文件。

---

## B. 有电脑 + Android Studio（最快，约 5 分钟）

1. Android Studio 打开 `Android_原生App工程` 目录，等 Gradle Sync 完成（首次会下载依赖）。
2. 手机：设置 → 关于手机 → 连点「版本号」7 次开启开发者选项 → 打开「USB 调试」→ 数据线连电脑。
3. 点顶部 **Run ▶**，选择你的手机，自动编译并安装。
   或 **Build → Build App Bundle(s) / APK(s) → Build APK(s)**，把生成的 APK 传到手机装。

> 工程里没有 `gradlew` 脚本和 wrapper jar，Android Studio 打开时会自动补齐，不影响使用。

---

## C. 不装 APK，只想马上看全屏效果

1. 把 `PWA_添加到主屏/` 整个目录部署到 **HTTPS** 静态托管。GitHub Pages 免费做法：
   - 新建仓库 → 把目录里所有文件传到仓库根目录 → **Settings → Pages → Source 选 `main` / `root`** → 保存。
   - 得到地址 `https://你的用户名.github.io/仓库名/`。
2. 手机 Chrome 打开该地址 → 菜单「⋮」→「安装应用」或「添加到主屏幕」。
3. 从桌面图标启动：独立窗口、无地址栏、无底部工具栏，离线也能用。

注意：局域网 `http://192.168.x.x` 只是本地预览，Chrome 不会给安装按钮（PWA 要求安全上下文）。要装就得 HTTPS。

---

## 装好之后是什么样

- 从桌面图标启动，没有浏览器框；系统状态栏和导航栏也隐藏，页面自绘的状态栏顶在最上面。
- 联系人、拨号盘、通话界面、最近通话、主题、导入导出全部保留。
- 点「用系统拨号器拨打」会真的调起系统拨号器（`tel:` → `ACTION_DIAL`），不需要电话权限。
- 应用内的呼叫/接听/计时仍是高仿真模拟，浏览器和 WebView 都接不进运营商语音网络。

## 小提醒

- Debug APK 用调试签名，自己用没问题；要上架应用商店需要正式签名。
- 数据存在 App 私有目录，卸载才会清。
- 若 GitHub Actions 报 SDK 许可错误，运行时会自动 `sdkmanager --licenses` 接受，无需手动处理。
